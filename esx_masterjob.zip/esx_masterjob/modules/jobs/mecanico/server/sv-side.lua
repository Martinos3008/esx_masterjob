ESX = nil
TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

TriggerEvent('esx_phone:registerNumber', 'mechanic', "Emergencias automovilísticas", true, true)
TriggerEvent('esx_society:registerSociety', 'mechanic', 'Mecánico', 'society_mechanic', 'society_mechanic', 'society_mechanic', {type = 'public'})

RegisterServerEvent('mecanico:server:sacar')
AddEventHandler('mecanico:server:sacar', function(itemName, count)
	local xPlayer = ESX.GetPlayerFromId(source)

	TriggerEvent('esx_addoninventory:getSharedInventory', 'society_mechanic', function(inventory)
		local item = inventory.getItem(itemName)

		-- is there enough in the society?
		if count > 0 and item.count >= count then

			-- can the player carry the said amount of x item?
			if xPlayer.canCarryItem(itemName, count) then
				inventory.removeItem(itemName, count)
				xPlayer.addInventoryItem(itemName, count)
				xPlayer.showNotification("Has retirado " .. count .. "x de " .. item.label)
			else
				xPlayer.showNotification("No tienes suficiente espacio")
			end
		else
			xPlayer.showNotification("Cantidad inválida")
		end
	end)
end)

ESX.RegisterServerCallback('mecanico:server:sacarcb', function(source, cb)
	TriggerEvent('esx_addoninventory:getSharedInventory', 'society_mechanic', function(inventory)
		cb(inventory.items)
	end)
end)

RegisterServerEvent('mecanico:server:trash')
AddEventHandler('mecanico:server:trash', function(itemName, count)
	local xPlayer = ESX.GetPlayerFromId(source)

	TriggerEvent('esx_addoninventory:getSharedInventory', 'society_mechanic', function(inventory)
		local item = inventory.getItem(itemName)
		local playerItemCount = xPlayer.getInventoryItem(itemName).count

		if item.count >= 0 and count <= playerItemCount then
			xPlayer.removeInventoryItem(itemName, count)
		else
			xPlayer.showNotification("Cantidad inválida")
		end

		xPlayer.showNotification("Has depositado " ..count.. "x de " .. item.label)
	end)
end)

RegisterServerEvent('mecanico:server:depositar')
AddEventHandler('mecanico:server:depositar', function(itemName, count)
	local xPlayer = ESX.GetPlayerFromId(source)

	TriggerEvent('esx_addoninventory:getSharedInventory', 'society_mechanic', function(inventory)
		local item = inventory.getItem(itemName)
		local playerItemCount = xPlayer.getInventoryItem(itemName).count

		if item.count >= 0 and count <= playerItemCount then
			xPlayer.removeInventoryItem(itemName, count)
			inventory.addItem(itemName, count)
		else
			xPlayer.showNotification("Cantidad inválida")
		end

		xPlayer.showNotification("Has depositado " ..count.. "x de " .. item.label)
	end)
end)

ESX.RegisterServerCallback('mecanico:server:depositarcb', function(source, cb)
	local xPlayer    = ESX.GetPlayerFromId(source)
	local items      = xPlayer.inventory

	cb({items = items})
end)