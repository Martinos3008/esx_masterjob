Config = {}
Config.DrawDistance = 10.0

Config.LSPD = {

	ArmarioLSPD = {
		Pos   = { x = 445.4, y = -983.8,z = 30.7},
		Size  = { x = 0.5, y = 0.5, z = 0.5 },
		Color = { r = 0, g = 0, b = 255 },
        Type  = 20
	},

	VehiculosLSPD = {
		Pos   = { x = 459.29, y = -1007.94, z = 28.15 },
		Size  = { x = 0.5, y = 0.5, z = 0.5 },
		Color = { r = 0, g = 0, b = 255 },
		Type  = 20
	}
}

Config.banda = {

	Armariobanda = {
		Pos   = { x = -1501.5093994141, y = 856.9306640625, z = 181.59492492676},
		Size  = { x = 0.5, y = 0.5, z = 0.5 },
		Color = { r = 0, g = 0, b = 255 },
        Type  = 20
	},

	Vehiculosbanda = {
		Pos   = { x = -1529.6451416016, y = 887.60046386719, z = 181.8553314209},
		Size  = { x = 0.5, y = 0.5, z = 0.5 },
		Color = { r = 0, g = 0, b = 255 },
		Type  = 20
	}
}



Config.Mecanico = {

	ArmarioLSC = {
		Pos   = { x = -206.65560913086, y = -1341.6083984375, z = 34.894596099854},
		Size  = { x = 0.5, y = 0.5, z = 0.5 },
		Color = { r = 0, g = 0, b = 255 },
        Type  = 20
	},

	VehiculosLSC = {
		Pos   = { x = -202.13780212402, y = -1309.6726074219,  z= 31.294134140015},
		Size  = { x = 0.5, y = 0.5, z = 0.5 },
		Color = { r = 0, g = 0, b = 255 },
		Type  = 20
	}
}

Config.EMS = {

	ArmarioEMS = {
		Pos   = { x = 301.3054, y = -600.2374, z = 43.2821},
		Size  = { x = 0.5, y = 0.5, z = 0.5 },
		Color = { r = 0, g = 0, b = 255 },
        Type  = 20
	},

	-- VehiculosEMS = {
	-- 	Pos   = { x = 296.07, y = -607.52, z = 43.33 },
	-- 	Size  = { x = 0.5, y = 0.5, z = 0.5 },
	-- 	Color = { r = 0, g = 0, b = 255 },
	-- 	Type  = 20
	-- }
}

Config.MecanicoJefe = {

	JefeLSC = {
		Pos   = { x = -355.18, y = -144.18, z = 42.20 },
		Size  = { x = 0.5, y = 0.5, z = 0.5 },
		Color = { r = 0, g = 0, b = 255 },
		Type  = 20
	}
}

Config.LSPDJefe = {

	JefeLSPD = {
		Pos   = { x = 433.86050415039, y = -981.93841552734, z = 25.698152542114 },
		Size  = { x = 0.5, y = 0.5, z = 0.5 },
		Color = { r = 0, g = 0, b = 255 },
		Type  = 20
	}
}

Config.EMSJefe = {

	JefeEMS = {
		Pos   = { x = 339.16, y = -595.69, z = 42.50 },
		Size  = { x = 0.5, y = 0.5, z = 0.5 },
		Color = { r = 0, g = 0, b = 255 },
		Type  = 20
	}
}

Config.bandaJefe = {

	JefeEMS = {
		Pos   = { x = 339.16, y = -595.69, z = 42.50 },
		Size  = { x = 0.5, y = 0.5, z = 0.5 },
		Color = { r = 0, g = 0, b = 255 },
		Type  = 20
	}
}